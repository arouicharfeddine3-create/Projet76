package com.automation.workflow.data

import android.content.Context
import com.automation.workflow.domain.models.EditorConnection
import com.automation.workflow.domain.models.EditorNode
import com.automation.workflow.domain.models.NodeType
import com.automation.workflow.domain.models.PortDef
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class NodeRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("workflow_editor", Context.MODE_PRIVATE)
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true; encodeDefaults = true }

    fun defaultNodesFor(workflowId: String): MutableList<EditorNode> {
        val templates = NodeType.templates()
        val start = templates.first { it.type == NodeType.MANUAL_TRIGGER }
        val script = templates.first { it.type == NodeType.JAVASCRIPT }
        val log = templates.first { it.type == NodeType.LOG_OUTPUT }
        val http = templates.first { it.type == NodeType.HTTP_REQUEST }
        val cond = templates.first { it.type == NodeType.IF_CONDITION }

        return mutableListOf(
            buildNode(workflowId, start, 120f, 220f),
            buildNode(workflowId, http, 420f, 120f),
            buildNode(workflowId, script, 420f, 320f),
            buildNode(workflowId, cond, 720f, 220f),
            buildNode(workflowId, log, 1020f, 120f),
            buildNode(workflowId, log, 1020f, 340f).let {
                it.title = "سجل (خطأ)"
                it.config["level"] = "ERROR"
                it
            }
        )
    }

    fun defaultConnectionsFor(nodes: List<EditorNode>): MutableList<EditorConnection> {
        if (nodes.size < 6) return mutableListOf()
        return mutableListOf(
            EditorConnection("c1", nodes[0].id, "out", nodes[1].id, "in"),
            EditorConnection("c2", nodes[0].id, "out", nodes[2].id, "in", 0xFFFFCA28),
            EditorConnection("c3", nodes[1].id, "out", nodes[3].id, "in"),
            EditorConnection("c4", nodes[2].id, "out", nodes[3].id, "in", 0xFFFFCA28),
            EditorConnection("c5", nodes[3].id, "true", nodes[4].id, "in", 0xFF66BB6A),
            EditorConnection("c6", nodes[3].id, "false", nodes[5].id, "in", 0xFFEF5350)
        )
    }

    fun buildNode(workflowId: String, template: com.automation.workflow.domain.models.NodeTemplate, x: Float, y: Float): EditorNode {
        return EditorNode(
            id = "n_${workflowId}_${System.currentTimeMillis()}_${Math.random().toString(36).takeLast(4)}",
            type = template.type,
            x = x, y = y,
            width = 220f, height = estimateHeight(template),
            title = template.title,
            script = template.defaultScript,
            config = template.defaultConfig.toMutableMap(),
            color = template.category.color.value.toLong()
        )
    }

    private fun estimateHeight(template: com.automation.workflow.domain.models.NodeTemplate): Float {
        val configCount = template.defaultConfig.size
        return 120f + configCount * 26f
    }

    fun saveScript(key: String, script: String) {
        prefs.edit().putString("script_$key", script).apply()
    }

    fun loadScript(key: String): String? = prefs.getString("script_$key", null)

    fun saveDraft(workflowId: String, nodes: List<EditorNode>, connections: List<EditorConnection>) {
        prefs.edit()
            .putString("nodes_$workflowId", json.encodeToString(nodes))
            .putString("conns_$workflowId", json.encodeToString(connections))
            .apply()
    }

    fun loadNodes(workflowId: String): List<EditorNode>? {
        val s = prefs.getString("nodes_$workflowId", null) ?: return null
        return try { json.decodeFromString(s) } catch (_: Exception) { null }
    }

    fun loadConnections(workflowId: String): List<EditorConnection>? {
        val s = prefs.getString("conns_$workflowId", null) ?: return null
        return try { json.decodeFromString(s) } catch (_: Exception) { null }
    }
}
