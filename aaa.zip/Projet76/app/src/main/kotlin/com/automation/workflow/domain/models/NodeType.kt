package com.automation.workflow.domain.models

import androidx.compose.ui.graphics.Color
import com.automation.workflow.ui.theme.*
import kotlinx.serialization.Serializable

@Serializable
enum class NodeCategory(val displayNameAr: String, val colorHex: ULong) {
    TRIGGER("المشغلات", 0xFF43A047UL),
    ACTION("الإجراءات", 0xFF1E88E5UL),
    LOGIC("المنطق", 0xFF8E24AAUL),
    DATA("البيانات", 0xFFFB8C00UL),
    CODE("الكود", 0xFFE53935UL),
    FLOW("التحكم", 0xFF00ACC1UL),
    AI("الذكاء الاصطناعي", 0xFFAD1457UL),
    NETWORK("الشبكة", 0xFF6D4C41UL),
    MEDIA("الوسائط", 0xFF7CB342UL),
    NAVIGATION("التنقل", 0xFF3949ABUL);

    val color: Color get() = Color(colorHex)
}

@Serializable
data class NodeTemplate(
    val type: NodeType,
    val category: NodeCategory,
    val title: String,
    val subtitle: String = "",
    val icon: String = "⚡",
    val inputs: List<PortDef> = listOf(PortDef("in", "دخل", PortFlowType.TRIGGER)),
    val outputs: List<PortDef> = listOf(PortDef("out", "خرج", PortFlowType.TRIGGER)),
    val defaultScript: String = "",
    val defaultConfig: Map<String, String> = emptyMap()
)

@Serializable
data class PortDef(
    val id: String,
    val label: String,
    val flow: PortFlowType,
    val dataType: DataType = DataType.ANY
)

@Serializable
enum class PortFlowType { TRIGGER, DATA }

@Serializable
enum class DataType { STRING, NUMBER, BOOLEAN, OBJECT, ARRAY, ANY }

@Serializable
enum class NodeType(val label: String, val category: NodeCategory, val icon: String) {
    // Triggers
    MANUAL_TRIGGER("تشغيل يدوي", NodeCategory.TRIGGER, "▶️"),
    WEBHOOK("Webhook", NodeCategory.TRIGGER, "🌐"),
    CRON_SCHEDULE("جدولة زمنية", NodeCategory.TRIGGER, "⏰"),
    NFC_TRIGGER("NFC", NodeCategory.TRIGGER, "📡"),
    QR_TRIGGER("QR Code", NodeCategory.TRIGGER, "📷"),
    FILE_WATCHER("مراقبة ملف", NodeCategory.TRIGGER, "👁️"),
    APP_EVENT("حدث التطبيق", NodeCategory.TRIGGER, "📲"),
    NOTIFICATION_EVENT("إشعار وارد", NodeCategory.TRIGGER, "🔔"),
    BOOT_TRIGGER("عند تشغيل الجهاز", NodeCategory.TRIGGER, "🔄"),
    SHAKE_TRIGGER("هز الجهاز", NodeCategory.TRIGGER, "📳"),
    LOCATION_TRIGGER("الموقع الجغرافي", NodeCategory.TRIGGER, "📍"),
    TIME_TRIGGER("وقت محدد", NodeCategory.TRIGGER, "⌚"),

    // Network
    HTTP_REQUEST("طلب HTTP", NodeCategory.NETWORK, "🌍"),
    WEBHOOK_SEND("إرسال Webhook", NodeCategory.NETWORK, "📤"),
    DOWNLOAD_FILE("تحميل ملف", NodeCategory.NETWORK, "⬇️"),
    UPLOAD_FILE("رفع ملف", NodeCategory.NETWORK, "⬆️"),
    API_CALL("استدعاء API", NodeCategory.NETWORK, "🔌"),
    SOCKET_CONNECT("WebSocket", NodeCategory.NETWORK, "🔗"),
    RSS_FEED("تغذية RSS", NodeCategory.NETWORK, "📰"),
    EMAIL_SEND("إرسال بريد", NodeCategory.NETWORK, "📧"),
    SMS_SEND("إرسال SMS", NodeCategory.NETWORK, "💬"),
    TELEGRAM_SEND("Telegram", NodeCategory.NETWORK, "✈️"),
    WHATSAPP_SEND("WhatsApp", NodeCategory.NETWORK, "💚"),
    FTP_TRANSFER("نقل FTP", NodeCategory.NETWORK, "🗄️"),

    // Data
    SET_VARIABLE("تعيين متغير", NodeCategory.DATA, "📝"),
    GET_VARIABLE("قراءة متغير", NodeCategory.DATA, "📖"),
    JSON_PARSE("تحليل JSON", NodeCategory.DATA, "🔍"),
    JSON_BUILD("بناء JSON", NodeCategory.DATA, "🧱"),
    TEXT_CONCAT("دمج نصوص", NodeCategory.DATA, "🔡"),
    REGEX_MATCH("بحث regex", NodeCategory.DATA, "🔎"),
    MATH_EXPR("عملية حسابية", NodeCategory.DATA, "➗"),
    LIST_OPERATIONS("عمليات قائمة", NodeCategory.DATA, "📋"),
    MAP_TRANSFORM("تحويل بيانات", NodeCategory.DATA, "🗺️"),
    FILTER_DATA("تصفية بيانات", NodeCategory.DATA, "🔻"),
    SORT_DATA("فرز بيانات", NodeCategory.DATA, "↕️"),
    CSV_READ("قراءة CSV", NodeCategory.DATA, "📊"),
    CSV_WRITE("كتابة CSV", NodeCategory.DATA, "📉"),
    DATABASE_QUERY("استعلام قاعدة بيانات", NodeCategory.DATA, "🗃️"),
    ENCODING("تشفير/فك تشفير", NodeCategory.DATA, "🔐"),
    HASH("تجزئة (Hash)", NodeCategory.DATA, "#️⃣"),

    // Logic / Flow Control
    IF_CONDITION("شرط If", NodeCategory.LOGIC, "❓"),
    SWITCH_CASE("تعدد الحالات", NodeCategory.LOGIC, "🔀"),
    LOOP_FOR("حلقة For", NodeCategory.LOGIC, "🔁"),
    LOOP_WHILE("حلقة While", NodeCategory.LOGIC, "🔂"),
    MERGE("دمج (Merge)", NodeCategory.FLOW, "🔗"),
    DELAY_WAIT("انتظار", NodeCategory.FLOW, "⏳"),
    ERROR_HANDLER("معالج الأخطاء", NodeCategory.FLOW, "⚠️"),
    TRY_CATCH("Try/Catch", NodeCategory.FLOW, "🛡️"),
    PARALLEL("تشغيل متوازي", NodeCategory.FLOW, "⫸⫷"),
    BREAK("إيقاف الحلقة", NodeCategory.FLOW, "⛔"),
    CONTINUE("متابعة الحلقة", NodeCategory.FLOW, "⏭️"),
    SUB_WORKFLOW("سير فرعي", NodeCategory.FLOW, "📦"),
    COMMENT("تعليق", NodeCategory.FLOW, "💬"),

    // Code
    JAVASCRIPT("JavaScript", NodeCategory.CODE, "🟨"),
    PYTHON_SCRIPT("Python", NodeCategory.CODE, "🐍"),
    KOTLIN_SCRIPT("Kotlin", NodeCategory.CODE, "🟪"),
    SHELL_SCRIPT("Shell", NodeCategory.CODE, "💻"),
    EXPRESSION("تعبير (Expression)", NodeCategory.CODE, "🧮"),
    SCRIPT_FILE("ملف سكريبت", NodeCategory.CODE, "📜"),
    EVAL("تنفيذ ديناميكي", NodeCategory.CODE, "⚡"),

    // Actions / Media
    NOTIFICATION_SHOW("إشعار", NodeCategory.ACTION, "🔔"),
    TOAST_MESSAGE("رسالة Toast", NodeCategory.ACTION, "💡"),
    VIBRATE("اهتزاز", NodeCategory.ACTION, "📳"),
    SPEAK_TTS("نطق (TTS)", NodeCategory.MEDIA, "🔊"),
    CLIPBOARD_COPY("نسخ للحافظة", NodeCategory.ACTION, "📋"),
    CLIPBOARD_PASTE("لصق من الحافظة", NodeCategory.ACTION, "📌"),
    DIALOG("مربع حوار", NodeCategory.ACTION, "🗨️"),
    PLAY_SOUND("تشغيل صوت", NodeCategory.MEDIA, "🎵"),
    RECORD_AUDIO("تسجيل صوت", NodeCategory.MEDIA, "🎙️"),
    CAMERA_CAPTURE("التقاط صورة", NodeCategory.MEDIA, "📸"),
    GALLERY_PICK("اختيار صورة", NodeCategory.MEDIA, "🖼️"),
    MEDIA_SCAN("فحص الوسائط", NodeCategory.MEDIA, "🎞️"),

    // Navigation
    GO_TO_SCREEN("الانتقال لشاشة", NodeCategory.NAVIGATION, "🧭"),
    OPEN_APP("فتح تطبيق", NodeCategory.NAVIGATION, "🚀"),
    OPEN_URL("فتح رابط", NodeCategory.NAVIGATION, "🔗"),
    CLOSE_APP("إغلاق التطبيق", NodeCategory.NAVIGATION, "❌"),
    SHARE_CONTENT("مشاركة", NodeCategory.NAVIGATION, "📤"),
    SAVE_TO_CLOUD("حفظ سحابي", NodeCategory.NAVIGATION, "☁️"),
    FILE_PICKER("اختيار ملف", NodeCategory.NAVIGATION, "📂"),
    INTENT_SEND("إرسال Intent", NodeCategory.NAVIGATION, "📨"),

    // AI
    AI_OPENAI("OpenAI / GPT", NodeCategory.AI, "🤖"),
    AI_GEMINI("Gemini", NodeCategory.AI, "🧠"),
    AI_TRANSLATE("ترجمة", NodeCategory.AI, "🌏"),
    AI_SUMMARY("تلخيص", NodeCategory.AI, "📝"),
    AI_IMAGE_GEN("توليد صور", NodeCategory.AI, "🎨"),
    AI_OCR("التعرف على النصوص", NodeCategory.AI, "🔤"),
    AI_CHATBOT("محادثة ذكية", NodeCategory.AI, "💬"),

    // Browser automation
    BROWSER_OPEN("فتح متصفح", NodeCategory.ACTION, "🌐"),
    BROWSER_CLICK("نقر عنصر", NodeCategory.ACTION, "👆"),
    BROWSER_TYPE("كتابة نص", NodeCategory.ACTION, "⌨️"),
    BROWSER_WAIT("انتظار تحميل", NodeCategory.FLOW, "⏱️"),
    BROWSER_EXTRACT("استخراج بيانات", NodeCategory.DATA, "📥"),
    BROWSER_SCROLL("تمرير", NodeCategory.ACTION, "📜"),
    BROWSER_SCREENSHOT("لقطة شاشة", NodeCategory.MEDIA, "📸"),
    SELECTOR_NODE("محدد CSS/XPath", NodeCategory.DATA, "🎯"),
    RACCORD_NODE("تسجيل Raccord", NodeCategory.ACTION, "🎬"),

    // Files
    FILE_READ("قراءة ملف", NodeCategory.DATA, "📄"),
    FILE_WRITE("كتابة ملف", NodeCategory.DATA, "📝"),
    FILE_DELETE("حذف ملف", NodeCategory.DATA, "🗑️"),
    FILE_COPY("نسخ ملف", NodeCategory.DATA, "📑"),
    FILE_MOVE("نقل ملف", NodeCategory.DATA, "➡️"),
    FILE_LIST("قائمة الملفات", NodeCategory.DATA, "📁"),
    FILE_ZIP("ضغط ZIP", NodeCategory.DATA, "🤐"),
    FILE_UNZIP("فك ضغط ZIP", NodeCategory.DATA, "📦"),
    LOG_OUTPUT("سجل (Log)", NodeCategory.ACTION, "📋");

    companion object {
        fun templates(): List<NodeTemplate> = values().map { type ->
            NodeTemplate(
                type = type,
                category = type.category,
                title = type.label,
                subtitle = type.category.displayNameAr,
                icon = type.icon,
                inputs = when (type.category) {
                    NodeCategory.TRIGGER -> listOf(
                        PortDef("out", "خرج", PortFlowType.TRIGGER)
                    )
                    else -> listOf(
                        PortDef("in", "دخل", PortFlowType.TRIGGER),
                        PortDef("out", "خرج", PortFlowType.TRIGGER)
                    )
                },
                outputs = when (type.category) {
                    NodeCategory.TRIGGER -> listOf(PortDef("out", "خرج", PortFlowType.TRIGGER))
                    NodeCategory.LOGIC -> when (type) {
                        IF_CONDITION -> listOf(
                            PortDef("true", "صحيح", PortFlowType.TRIGGER),
                            PortDef("false", "خاطئ", PortFlowType.TRIGGER)
                        )
                        SWITCH_CASE -> listOf(
                            PortDef("case1", "حالة 1", PortFlowType.TRIGGER),
                            PortDef("case2", "حالة 2", PortFlowType.TRIGGER),
                            PortDef("case3", "حالة 3", PortFlowType.TRIGGER),
                            PortDef("default", "افتراضي", PortFlowType.TRIGGER)
                        )
                        ERROR_HANDLER, TRY_CATCH -> listOf(
                            PortDef("success", "نجاح", PortFlowType.TRIGGER),
                            PortDef("error", "خطأ", PortFlowType.TRIGGER)
                        )
                        else -> listOf(PortDef("out", "خرج", PortFlowType.TRIGGER))
                    }
                    else -> listOf(PortDef("out", "خرج", PortFlowType.TRIGGER))
                },
                defaultScript = defaultScriptFor(type),
                defaultConfig = defaultConfigFor(type)
            )
        }

        private fun defaultScriptFor(type: NodeType): String = when (type) {
            JAVASCRIPT -> "// عقدة JavaScript\n// استخدم المتغيرات $input, $nodes, $env\nfunction run(input) {\n  return { result: input };\n}\nrun($input);"
            PYTHON_SCRIPT -> "# عقدة Python\n# استخدم input للوصول إلى البيانات\ndef run(input):\n    return {\"result\": input}\nresult = run(input)"
            KOTLIN_SCRIPT -> "// عقدة Kotlin\nval result = input ?: \"\""
            SHELL_SCRIPT -> "#!/bin/sh\necho \"Hello from workflow\""
            EXPRESSION -> "// تعبير\ninput?.toString()?.length ?: 0"
            HTTP_REQUEST -> "// إعداد الطلب\nmethod = \"GET\"\nurl = \"https://api.example.com/data\""
            AI_OPENAI -> "// موجه الذكاء الاصطناعي\n\"لخّص النص التالي: \" + (input ?: \"\")"
            AI_GEMINI -> "// موجه Gemini\n\"أعطني إجابة عن: \" + (input ?: \"\")"
            MATH_EXPR -> "// عملية حسابية\nval a = 10; val b = 20; a + b"
            TEXT_CONCAT -> "// دمج\nval name = \"World\"\n\"Hello, $name!\""
            JSON_PARSE -> "// تحليل JSON\nJSON.parse(input ?: \"{}\")"
            JSON_BUILD -> "// بناء JSON\n({ key: \"value\", count: 42 })"
            IF_CONDITION -> "// شرط\ninput == true"
            else -> "// ${type.label}\n// اكتب السكريبت هنا..."
        }

        private fun defaultConfigFor(type: NodeType): Map<String, String> = when (type) {
            HTTP_REQUEST -> mapOf(
                "method" to "GET",
                "url" to "https://api.example.com",
                "headers" to "{}",
                "body" to ""
            )
            DELAY_WAIT -> mapOf("durationMs" to "1000")
            CRON_SCHEDULE -> mapOf("cron" to "0 * * * *")
            SET_VARIABLE -> mapOf("name" to "myVar", "value" to "")
            LOG_OUTPUT -> mapOf("level" to "INFO", "message" to "Hello!")
            SHOW_NOTIFICATION -> mapOf("title" to "Workflow", "body" to "Executed")
            AI_OPENAI -> mapOf("model" to "gpt-4o-mini", "apiKey" to "", "prompt" to "")
            else -> emptyMap()
        }
    }
}
