package com.automation.workflow.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SettingsState(
    val darkMode: Boolean = true,
    val arabic: Boolean = true,
    val fontSize: Int = 14,
    val autoSave: Boolean = true,
    val notifications: Boolean = true,
    val sounds: Boolean = true,
    val vibration: Boolean = true,
    val biometric: Boolean = false,
    val nodeTimeout: Long = 30000L,
    val gridEnabled: Boolean = true,
    val snapToGrid: Boolean = false,
    val animateConnections: Boolean = true,
    val animationSpeed: Float = 1f,
    val batterySaver: Boolean = false
)

class SettingsViewModel(context: Context) : ViewModel() {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    private fun load(): SettingsState {
        return SettingsState(
            darkMode = prefs.getBoolean("darkMode", true),
            arabic = prefs.getBoolean("arabic", true),
            fontSize = prefs.getInt("fontSize", 14),
            autoSave = prefs.getBoolean("autoSave", true),
            notifications = prefs.getBoolean("notifications", true),
            sounds = prefs.getBoolean("sounds", true),
            vibration = prefs.getBoolean("vibration", true),
            biometric = prefs.getBoolean("biometric", false),
            nodeTimeout = prefs.getLong("nodeTimeout", 30000L),
            gridEnabled = prefs.getBoolean("gridEnabled", true),
            snapToGrid = prefs.getBoolean("snapToGrid", false),
            animateConnections = prefs.getBoolean("animateConnections", true),
            animationSpeed = prefs.getFloat("animationSpeed", 1f),
            batterySaver = prefs.getBoolean("batterySaver", false)
        )
    }

    private fun save(s: SettingsState) {
        _state.value = s
        prefs.edit().apply {
            putBoolean("darkMode", s.darkMode)
            putBoolean("arabic", s.arabic)
            putInt("fontSize", s.fontSize)
            putBoolean("autoSave", s.autoSave)
            putBoolean("notifications", s.notifications)
            putBoolean("sounds", s.sounds)
            putBoolean("vibration", s.vibration)
            putBoolean("biometric", s.biometric)
            putLong("nodeTimeout", s.nodeTimeout)
            putBoolean("gridEnabled", s.gridEnabled)
            putBoolean("snapToGrid", s.snapToGrid)
            putBoolean("animateConnections", s.animateConnections)
            putFloat("animationSpeed", s.animationSpeed)
            putBoolean("batterySaver", s.batterySaver)
        }.apply()
    }

    fun update(transform: (SettingsState) -> SettingsState) {
        save(transform(_state.value))
    }
}
