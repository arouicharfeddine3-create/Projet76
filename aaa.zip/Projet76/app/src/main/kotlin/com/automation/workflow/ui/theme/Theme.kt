package com.automation.workflow.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Blue500 = Color(0xFF2196F3)
val Blue700 = Color(0xFF1976D2)
val Blue900 = Color(0xFF0D47A1)
val Orange500 = Color(0xFFFF9800)
val Green500 = Color(0xFF4CAF50)
val Red500 = Color(0xFFF44336)
val Purple500 = Color(0xFF9C27B0)
val Teal500 = Color(0xFF009688)

val DarkBackground = Color(0xFF0A0F1C)
val DarkSurface = Color(0xFF1E293B)
val DarkSurface2 = Color(0xFF273449)
val OnDark = Color(0xFFECEFF1)
val GridColor = Color(0x15FFFFFF)
val ConnectionColor = Color(0xFF64B5F6)

private val DarkColors = darkColorScheme(
    primary = Blue500,
    onPrimary = Color.White,
    secondary = Orange500,
    onSecondary = Color.Black,
    background = DarkBackground,
    onBackground = OnDark,
    surface = DarkSurface,
    onSurface = OnDark,
    error = Red500,
    tertiary = Teal500
)

private val LightColors = lightColorScheme(
    primary = Blue700,
    onPrimary = Color.White,
    secondary = Orange500,
    background = Color(0xFFF5F7FB),
    surface = Color.White,
    onBackground = Color(0xFF0A0F1C),
    onSurface = Color(0xFF0A0F1C)
)

val Typography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 14.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp
    )
)

@Composable
fun WorkflowTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
