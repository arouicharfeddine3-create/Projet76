package com.automation.workflow.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.automation.workflow.data.WorkflowRepository
import com.automation.workflow.domain.models.Workflow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(private val repo: WorkflowRepository) : ViewModel() {
    private val _workflows = MutableStateFlow<List<Workflow>>(emptyList())
    val workflows: StateFlow<List<Workflow>> = _workflows.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _workflows.value = repo.listWorkflows()
        }
    }

    fun createNew(name: String = "سير عمل جديد"): Workflow {
        val wf = repo.createWorkflow(name)
        refresh()
        return wf
    }

    fun delete(id: String) {
        repo.delete(id)
        refresh()
    }

    fun search(q: String) {
        _searchQuery.value = q
        _workflows.value = repo.listWorkflows().filter {
            it.name.contains(q, ignoreCase = true) || it.description.contains(q, ignoreCase = true)
        }
    }
}
