package com.automation.workflow.ui.editor

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.automation.workflow.domain.models.EditorNode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NodePropertyPanel(
    node: EditorNode,
    onClose: () -> Unit,
    onOpenScript: () -> Unit,
    onTitleChange: (String) -> Unit,
    onConfigChange: (String, String) -> Unit,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit,
    onBreakpoint: () -> Unit,
    onDisable: () -> Unit,
    onDeleteConnection: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(320.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 10.dp
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⚙️ خصائص العقدة", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) }
                }
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = node.title,
                    onValueChange = onTitleChange,
                    label = { Text("اسم العقدة") },
                    leadingIcon = { Icon(Icons.Default.Title, null) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(Modifier.height(8.dp))

                // Actions
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onOpenScript,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(node.color))
                    ) {
                        Icon(Icons.Default.Code, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("السكريبت", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = onDuplicate, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("نسخ", fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = node.isBreakpoint,
                        onClick = onBreakpoint,
                        label = { Text("نقطة توقف", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Adjust, null, modifier = Modifier.size(14.dp)) }
                    )
                    FilterChip(
                        selected = node.isDisabled,
                        onClick = onDisable,
                        label = { Text(if (node.isDisabled) "مُعطّل" else "تعطيل", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Block, null, modifier = Modifier.size(14.dp)) }
                    )
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))

                Text("📐 إعدادات العقدة", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(node.config.entries.toList()) { (k, v) ->
                        var value by remember(k, v) { mutableStateOf(v) }
                        OutlinedTextField(
                            value = value,
                            onValueChange = { value = it; onConfigChange(k, it) },
                            label = { Text(k, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onDelete,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Delete, null)
                    Spacer(Modifier.width(6.dp))
                    Text("حذف العقدة")
                }
            }
        }
    }
}
