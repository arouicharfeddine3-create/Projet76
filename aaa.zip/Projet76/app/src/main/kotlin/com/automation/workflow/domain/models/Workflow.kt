package com.automation.workflow.domain.models

import kotlinx.serialization.Serializable

@Serializable
data class Workflow(
    val id: String,
    val name: String,
    val description: String = "",
    val nodes: MutableList<EditorNode> = mutableListOf(),
    val connections: MutableList<EditorConnection> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class EditorNode(
    val id: String,
    val type: NodeType,
    var x: Float = 200f,
    var y: Float = 200f,
    var width: Float = 220f,
    var height: Float = 120f,
    var title: String = "",
    var script: String = "",
    var config: MutableMap<String, String> = mutableMapOf(),
    var color: Long = 0xFF1E88E5,
    var isBreakpoint: Boolean = false,
    var isDisabled: Boolean = false
)

@Serializable
data class EditorPort(
    val id: String,
    val nodeId: String,
    val isOutput: Boolean,
    val label: String
)

@Serializable
data class EditorConnection(
    val id: String,
    val fromNodeId: String,
    val fromPortId: String,
    val toNodeId: String,
    val toPortId: String,
    var color: Long = 0xFF90CAF9
)
