package com.automation.workflow.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.automation.workflow.data.WorkflowRepository
import com.automation.workflow.domain.models.ExecutionStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LogLine(val time: String, val level: String, val message: String, val node: String? = null)

class RunnerViewModel(private val repo: WorkflowRepository) : ViewModel() {
    private val _workflows = MutableStateFlow(repo.listWorkflows())
    val workflows: StateFlow<List<com.automation.workflow.domain.models.Workflow>> = _workflows.asStateFlow()

    private val _selectedId = MutableStateFlow<String?>(null)
    val selectedId: StateFlow<String?> = _selectedId.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _status = MutableStateFlow(ExecutionStatus.PENDING)
    val status: StateFlow<ExecutionStatus> = _status.asStateFlow()

    init {
        val first = _workflows.value.firstOrNull()
        _selectedId.value = first?.id
    }

    fun select(id: String) { _selectedId.value = id }

    fun run() {
        val id = _selectedId.value ?: return
        _status.value = ExecutionStatus.RUNNING
        _logs.value = _logs.value + LogLine(now(), "INFO", "🚀 بدء تشغيل السير العمل")
        val wf = _workflows.value.firstOrNull { it.id == id } ?: return
        val nodeCount = wf.nodes.size
        _logs.value = _logs.value + LogLine(now(), "INFO", "📦 عدد العقد: $nodeCount", null)
        wf.nodes.forEachIndexed { i, n ->
            _logs.value = _logs.value + LogLine(now(), "DEBUG", "⚙️ جاري تشغيل ${n.title}", n.title)
            _logs.value = _logs.value + LogLine(now(), "SUCCESS", "✅ اكتمل ${n.title}", n.title)
        }
        _logs.value = _logs.value + LogLine(now(), "SUCCESS", "🏁 اكتمل السير العمل بنجاح")
        _status.value = ExecutionStatus.SUCCESS
    }

    fun stop() {
        _status.value = ExecutionStatus.CANCELLED
        _logs.value = _logs.value + LogLine(now(), "WARNING", "⏹️ تم إيقاف التشغيل")
    }

    fun clear() { _logs.value = emptyList() }

    private fun now() = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
}
