package com.automation.workflow

import android.app.Application
import com.automation.workflow.data.NodeRepository
import com.automation.workflow.data.WorkflowRepository
import com.automation.workflow.ui.viewmodel.EditorViewModel
import com.automation.workflow.ui.viewmodel.HomeViewModel
import com.automation.workflow.ui.viewmodel.LibraryViewModel
import com.automation.workflow.ui.viewmodel.RunnerViewModel
import com.automation.workflow.ui.viewmodel.SettingsViewModel
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.startKoin
import org.koin.dsl.module

class AutomationApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val appModule = module {
            single { NodeRepository(androidContext()) }
            single { WorkflowRepository(androidContext(), get()) }
            viewModel { HomeViewModel(get()) }
            viewModel { EditorViewModel(get()) }
            viewModel { RunnerViewModel(get()) }
            viewModel { LibraryViewModel() }
            viewModel { SettingsViewModel(androidContext()) }
        }
        startKoin {
            androidContext(this@AutomationApp)
            modules(appModule)
        }
    }
}
