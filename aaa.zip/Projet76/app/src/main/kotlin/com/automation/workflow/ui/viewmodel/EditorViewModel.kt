package com.automation.workflow.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.automation.workflow.data.NodeRepository
import com.automation.workflow.data.WorkflowRepository
import com.automation.workflow.domain.models.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PendingConnection(
    val fromNodeId: String,
    val fromPortId: String,
    val isFromOutput: Boolean,
    val currentX: Float,
    val currentY: Float
)

data class DragNodeState(
    val nodeId: String,
    val offsetX: Float,
    val offsetY: Float
)

class EditorViewModel(
    private val workflowRepo: WorkflowRepository,
    private val nodeRepo: NodeRepository
) : ViewModel() {

    private val _workflow = MutableStateFlow<Workflow?>(null)
    val workflow: StateFlow<Workflow?> = _workflow.asStateFlow()

    private val _selectedNodeId = MutableStateFlow<String?>(null)
    val selectedNodeId: StateFlow<String?> = _selectedNodeId.asStateFlow()

    private val _editingNodeId = MutableStateFlow<String?>(null)
    val editingNodeId: StateFlow<String?> = _editingNodeId.asStateFlow()

    private val _scale = MutableStateFlow(1f)
    val scale: StateFlow<Float> = _scale.asStateFlow()

    private val _offsetX = MutableStateFlow(0f)
    val offsetX: StateFlow<Float> = _offsetX.asStateFlow()

    private val _offsetY = MutableStateFlow(0f)
    val offsetY: StateFlow<Float> = _offsetY.asStateFlow()

    private val _pending = MutableStateFlow<PendingConnection?>(null)
    val pending: StateFlow<PendingConnection?> = _pending.asStateFlow()

    private val _nodeSearch = MutableStateFlow("")
    val nodeSearch: StateFlow<String> = _nodeSearch.asStateFlow()

    private val _showAddMenu = MutableStateFlow(false)
    val showAddMenu: StateFlow<Boolean> = _showAddMenu.asStateFlow()

    private val _executionLog = MutableStateFlow<List<String>>(emptyList())
    val executionLog: StateFlow<List<String>> = _executionLog.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast.asStateFlow()

    private var autoSaveJob: Job? = null

    fun load(id: String) {
        var wf = workflowRepo.getWorkflow(id) ?: workflowRepo.createDefaultWorkflow()
        val savedNodes = nodeRepo.loadNodes(wf.id)
        val savedConns = nodeRepo.loadConnections(wf.id)
        if (savedNodes != null && savedConns != null) {
            wf = wf.copy(nodes = savedNodes.toMutableList(), connections = savedConns.toMutableList())
        }
        _workflow.value = wf
        startAutoSave()
    }

    private fun startAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            while (isActive) {
                delay(3000)
                save()
            }
        }
    }

    fun save() {
        val wf = _workflow.value ?: return
        workflowRepo.save(wf)
    }

    fun selectNode(id: String?) {
        _selectedNodeId.value = id
    }

    fun openScriptEditor(nodeId: String) {
        _editingNodeId.value = nodeId
        _selectedNodeId.value = nodeId
    }

    fun closeScriptEditor() {
        _editingNodeId.value = null
    }

    fun updateNodeScript(nodeId: String, script: String) {
        _workflow.value?.let { wf ->
            val idx = wf.nodes.indexOfFirst { it.id == nodeId }
            if (idx >= 0) {
                wf.nodes[idx] = wf.nodes[idx].copy(script = script)
                _workflow.value = wf
            }
        }
    }

    fun updateNodeTitle(nodeId: String, title: String) {
        _workflow.value?.let { wf ->
            val idx = wf.nodes.indexOfFirst { it.id == nodeId }
            if (idx >= 0) {
                wf.nodes[idx] = wf.nodes[idx].copy(title = title)
                _workflow.value = wf
            }
        }
    }

    fun updateNodeConfig(nodeId: String, key: String, value: String) {
        _workflow.value?.let { wf ->
            val idx = wf.nodes.indexOfFirst { it.id == nodeId }
            if (idx >= 0) {
                val node = wf.nodes[idx]
                node.config[key] = value
                _workflow.value = wf
            }
        }
    }

    fun updateNodePosition(nodeId: String, x: Float, y: Float) {
        _workflow.value?.let { wf ->
            val idx = wf.nodes.indexOfFirst { it.id == nodeId }
            if (idx >= 0) {
                wf.nodes[idx] = wf.nodes[idx].copy(x = x, y = y)
                _workflow.value = wf
            }
        }
    }

    fun toggleBreakpoint(nodeId: String) {
        _workflow.value?.let { wf ->
            val idx = wf.nodes.indexOfFirst { it.id == nodeId }
            if (idx >= 0) {
                wf.nodes[idx] = wf.nodes[idx].copy(isBreakpoint = !wf.nodes[idx].isBreakpoint)
                _workflow.value = wf
            }
        }
    }

    fun toggleDisabled(nodeId: String) {
        _workflow.value?.let { wf ->
            val idx = wf.nodes.indexOfFirst { it.id == nodeId }
            if (idx >= 0) {
                wf.nodes[idx] = wf.nodes[idx].copy(isDisabled = !wf.nodes[idx].isDisabled)
                _workflow.value = wf
            }
        }
    }

    fun deleteNode(nodeId: String) {
        _workflow.value?.let { wf ->
            wf.nodes.removeAll { it.id == nodeId }
            wf.connections.removeAll { it.fromNodeId == nodeId || it.toNodeId == nodeId }
            if (_selectedNodeId.value == nodeId) _selectedNodeId.value = null
            if (_editingNodeId.value == nodeId) _editingNodeId.value = null
            _workflow.value = wf
        }
    }

    fun duplicateNode(nodeId: String) {
        _workflow.value?.let { wf ->
            val src = wf.nodes.firstOrNull { it.id == nodeId } ?: return
            val copy = src.copy(
                id = "n_${wf.id}_${System.currentTimeMillis()}_${Math.random().toString(36).takeLast(4)}",
                x = src.x + 40f,
                y = src.y + 40f,
                title = src.title + " (نسخة)",
                config = src.config.toMutableMap()
            )
            wf.nodes.add(copy)
            _workflow.value = wf
            _selectedNodeId.value = copy.id
        }
    }

    fun addNode(template: NodeTemplate, canvasX: Float? = null, canvasY: Float? = null) {
        val wf = _workflow.value ?: return
        val node = nodeRepo.buildNode(
            wf.id, template,
            canvasX ?: (200f - _offsetX.value) / _scale.value,
            canvasY ?: (200f - _offsetY.value) / _scale.value
        )
        wf.nodes.add(node)
        _workflow.value = wf
        _showAddMenu.value = false
        _selectedNodeId.value = node.id
        _toast.value = "تمت إضافة: ${template.title}"
    }

    fun startConnection(nodeId: String, portId: String, isOutput: Boolean, x: Float, y: Float) {
        _pending.value = PendingConnection(nodeId, portId, isOutput, x, y)
    }

    fun updatePending(x: Float, y: Float) {
        _pending.value = _pending.value?.copy(currentX = x, currentY = y)
    }

    fun completeConnection(targetNodeId: String, targetPortId: String, targetIsOutput: Boolean) {
        val p = _pending.value ?: return
        val wf = _workflow.value ?: return
        if (p.fromNodeId == targetNodeId) { _pending.value = null; return }
        val (fromN, fromP, toN, toP) = if (p.isFromOutput && !targetIsOutput) {
            listOf(p.fromNodeId, p.fromPortId, targetNodeId, targetPortId)
        } else if (!p.isFromOutput && targetIsOutput) {
            listOf(targetNodeId, targetPortId, p.fromNodeId, p.fromPortId)
        } else { _pending.value = null; return }

        if (wf.connections.any { it.fromNodeId == fromN && it.fromPortId == fromP && it.toNodeId == toN && it.toPortId == toP }) {
            _pending.value = null; return
        }
        // Avoid duplicate input connections
        wf.connections.removeAll { it.toNodeId == toN && it.toPortId == toP }
        wf.connections.add(
            EditorConnection(
                id = "c_${System.currentTimeMillis()}",
                fromNodeId = fromN, fromPortId = fromP,
                toNodeId = toN, toPortId = toP
            )
        )
        _pending.value = null
        _workflow.value = wf
    }

    fun cancelConnection() { _pending.value = null }

    fun deleteConnection(id: String) {
        _workflow.value?.let { wf ->
            wf.connections.removeAll { it.id == id }
            _workflow.value = wf
        }
    }

    fun panBy(dx: Float, dy: Float) {
        _offsetX.value += dx
        _offsetY.value += dy
    }

    fun zoomAt(focusX: Float, focusY: Float, newScale: Float) {
        val clamped = newScale.coerceIn(0.3f, 2.5f)
        val old = _scale.value
        val ratio = clamped / old
        _offsetX.value = focusX - (focusX - _offsetX.value) * ratio
        _offsetY.value = focusY - (focusY - _offsetY.value) * ratio
        _scale.value = clamped
    }

    fun resetView() {
        _scale.value = 1f; _offsetX.value = 0f; _offsetY.value = 0f
    }

    fun setSearch(q: String) { _nodeSearch.value = q }
    fun showAddMenu(show: Boolean) { _showAddMenu.value = show }

    fun clearToast() { _toast.value = null }

    fun runWorkflow() {
        val wf = _workflow.value ?: return
        _isRunning.value = true
        _executionLog.value = listOf("[${timestamp()}] ▶️ بدء تشغيل: ${wf.name}")
        viewModelScope.launch {
            val ordered = topologicalOrder(wf)
            for (node in ordered) {
                if (node.isDisabled) {
                    log("⏭️ تخطي عقدة معطلة: ${node.title}")
                    continue
                }
                log("⚙️ تشغيل: ${node.title} (${node.type.label})")
                delay(400)
                if (node.isBreakpoint) {
                    log("⏸️ نقطة توقف عند: ${node.title}")
                    delay(600)
                }
                log("✅ انتهى: ${node.title}")
            }
            log("[${timestamp()}] 🏁 اكتمل التنفيذ")
            _isRunning.value = false
        }
    }

    private fun log(msg: String) {
        _executionLog.value = _executionLog.value + msg
    }

    private fun timestamp(): String = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())

    private fun topologicalOrder(wf: Workflow): List<EditorNode> {
        val byId = wf.nodes.associateBy { it.id }
        val inDeg = mutableMapOf<String, Int>()
        val graph = mutableMapOf<String, MutableList<String>>()
        for (n in wf.nodes) { inDeg[n.id] = 0; graph[n.id] = mutableListOf() }
        for (c in wf.connections) {
            graph[c.fromNodeId]?.add(c.toNodeId)
            inDeg[c.toNodeId] = (inDeg[c.toNodeId] ?: 0) + 1
        }
        val q = ArrayDeque<String>()
        for ((k,v) in inDeg) if (v == 0) q.add(k)
        val out = mutableListOf<EditorNode>()
        while (q.isNotEmpty()) {
            val id = q.removeFirst()
            byId[id]?.let { out.add(it) }
            for (next in graph[id]!!) {
                inDeg[next] = inDeg[next]!! - 1
                if (inDeg[next] == 0) q.add(next)
            }
        }
        // Add orphans
        for (n in wf.nodes) if (n.id !in out.map { it.id }.toSet()) out.add(n)
        return out
    }

    override fun onCleared() {
        autoSaveJob?.cancel()
        save()
        super.onCleared()
    }
}
