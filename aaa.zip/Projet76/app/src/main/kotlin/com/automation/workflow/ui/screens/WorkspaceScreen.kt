package com.automation.workflow.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun WorkspaceScreen() {
    data class WFile(val name: String, val type: String, val icon: String, val size: String = "--")
    val root = remember {
        listOf(
            WFile("scripts", "dir", "📁"),
            WFile("workflows", "dir", "📁"),
            WFile("exports", "dir", "📁"),
            WFile("downloads", "dir", "📁"),
            WFile("main.js", "js", "🟨", "2.3 KB"),
            WFile("scraper.py", "py", "🐍", "4.1 KB"),
            WFile("data.json", "json", "📋", "18 KB"),
            WFile("notes.md", "md", "📝", "1.2 KB"),
            WFile("report.csv", "csv", "📊", "32 KB"),
            WFile("image.png", "img", "🖼️", "220 KB"),
            WFile("backup.zip", "zip", "🤐", "1.4 MB")
        )
    }
    var selected by remember { mutableStateOf<WFile?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFFEF6C00), Color(0xFFE65100))))
                .padding(20.dp)
        ) {
            Column {
                Text("📂 مساحة العمل", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("أدر ملفات السكريبتات والبيانات والتصدير", color = Color.White.copy(0.85f), fontSize = 13.sp)
            }
        }

        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = "", onValueChange = {}, leadingIcon = { Icon(Icons.Default.Search, null) },
                placeholder = { Text("🔍 بحث في الملفات") }, modifier = Modifier.weight(1f))
            Button(onClick = {}) { Icon(Icons.Default.Add, null) }
        }

        Row(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // Breadcrumb
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                        Icon(Icons.Default.Folder, null, tint = Color(0xFFFFCA28), modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("/workspace", fontWeight = FontWeight.SemiBold)
                    }
                }
                items(root) { f ->
                    ElevatedCard(
                        onClick = { selected = f },
                        colors = CardDefaults.cardColors(containerColor = if (selected?.name == f.name) Color(0xFF1E88E5).copy(0.15f) else MaterialTheme.colorScheme.surface)
                    ) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(f.icon, fontSize = 22.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                if (f.type != "dir") Text(f.size, color = Color.Gray, fontSize = 11.sp)
                            }
                            IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, null, modifier = Modifier.size(18.dp)) }
                        }
                    }
                }
            }

            if (selected != null) {
                Surface(Modifier.width(280.dp).fillMaxHeight(), color = Color(0xFF1E293B)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(selected!!.icon, fontSize = 28.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(selected!!.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { selected = null }) { Icon(Icons.Default.Close, null, tint = Color.White) }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("النوع: ${selected!!.type}", color = Color.White.copy(0.8f), fontSize = 12.sp)
                        if (selected!!.type != "dir") Text("الحجم: ${selected!!.size}", color = Color.White.copy(0.8f), fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Text("معاينة:", color = Color.White.copy(0.6f), fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Surface(Modifier.fillMaxWidth().height(200.dp), color = Color(0xFF0F172A), shape = RoundedCornerShape(8.dp)) {
                            Box(Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    when (selected!!.type) {
                                        "dir" -> "📁 مجلد"
                                        in listOf("js","py","md","json","csv") -> "// محتوى الملف ${selected!!.name}\nconst sample = 'hello';\nconsole.log(sample);"
                                        "img" -> "🖼️ معاينة صورة"
                                        else -> "لا توجد معاينة"
                                    }, color = Color(0xFFE2E8F0), fontSize = 11.sp,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("فتح") }
                            OutlinedButton(onClick = {}) { Icon(Icons.Default.Share, null) }
                        }
                    }
                }
            }
        }
    }
}
