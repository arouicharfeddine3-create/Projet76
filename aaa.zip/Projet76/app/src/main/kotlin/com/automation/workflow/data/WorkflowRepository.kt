package com.automation.workflow.data

import android.content.Context
import com.automation.workflow.domain.models.Workflow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class WorkflowRepository(context: Context, private val nodeRepo: NodeRepository) {
    private val prefs = context.getSharedPreferences("workflow_app", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun listWorkflows(): List<Workflow> {
        val ids = prefs.getStringSet("workflow_ids", emptySet()) ?: emptySet()
        val list = ids.mapNotNull { id ->
            val raw = prefs.getString("wf_$id", null) ?: return@mapNotNull null
            try { json.decodeFromString<Workflow>(raw) } catch (_: Exception) { null }
        }.sortedByDescending { it.updatedAt }
        return list.ifEmpty { listOf(createDefaultWorkflow()) }
    }

    fun getWorkflow(id: String): Workflow? {
        val raw = prefs.getString("wf_$id", null) ?: return null
        return try { json.decodeFromString(raw) } catch (_: Exception) { null }
    }

    fun createWorkflow(name: String): Workflow {
        val id = "wf_${System.currentTimeMillis()}"
        val wf = Workflow(id = id, name = name)
        wf.nodes.addAll(nodeRepo.defaultNodesFor(id))
        wf.connections.addAll(nodeRepo.defaultConnectionsFor(wf.nodes))
        save(wf)
        return wf
    }

    fun createDefaultWorkflow(): Workflow {
        val existing = prefs.getString("wf_default_seeded", null)
        if (existing != null) return getWorkflow(existing) ?: createWorkflow("مشروعي الأول")
        val wf = createWorkflow("مشروعي الأول")
        prefs.edit().putString("wf_default_seeded", wf.id).apply()
        return wf
    }

    fun save(workflow: Workflow) {
        val copy = workflow.copy(updatedAt = System.currentTimeMillis())
        val ids = (prefs.getStringSet("workflow_ids", mutableSetOf()) ?: mutableSetOf()).toMutableSet()
        ids.add(copy.id)
        prefs.edit()
            .putStringSet("workflow_ids", ids)
            .putString("wf_${copy.id}", json.encodeToString(copy))
            .apply()
        nodeRepo.saveDraft(copy.id, copy.nodes, copy.connections)
    }

    fun delete(id: String) {
        val ids = (prefs.getStringSet("workflow_ids", mutableSetOf()) ?: mutableSetOf()).toMutableSet()
        ids.remove(id)
        prefs.edit()
            .putStringSet("workflow_ids", ids)
            .remove("wf_$id")
            .apply()
    }
}
