package com.automation.workflow.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.automation.workflow.domain.models.NodeCategory
import com.automation.workflow.domain.models.NodeType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LibraryItem(
    val name: String,
    val type: String,
    val language: String,
    val code: String,
    val description: String = "",
    val category: String = "مخصص"
)

class LibraryViewModel : ViewModel() {
    private val _scripts = MutableStateFlow(sampleScripts())
    val scripts: StateFlow<List<LibraryItem>> = _scripts.asStateFlow()

    private val _selected = MutableStateFlow<LibraryItem?>(null)
    val selected: StateFlow<LibraryItem?> = _selected.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    fun filter(q: String) {
        _query.value = q
        val all = sampleScripts()
        _scripts.value = if (q.isBlank()) all else all.filter {
            it.name.contains(q, true) || it.language.contains(q, true) || it.description.contains(q, true)
        }
    }

    fun select(item: LibraryItem) { _selected.value = item }

    fun updateCode(code: String) {
        _selected.value = _selected.value?.copy(code = code)
    }

    fun addNew() {
        val item = LibraryItem("سكريبت جديد", "script", "javascript", "// سكريبت جديد\nfunction main(input) {\n  return input;\n}", "سكريبت مخصص")
        _scripts.value = listOf(item) + _scripts.value
        _selected.value = item
    }

    fun categories(): List<NodeCategory> = NodeCategory.values().toList()
    fun templates() = NodeType.templates()
}

private fun sampleScripts() = listOf(
    LibraryItem("Fetch JSON", "script", "javascript",
        "// جلب بيانات JSON\nasync function fetchJson(url) {\n  const r = await fetch(url);\n  return await r.json();\n}\nreturn fetchJson($input?.url || 'https://api.example.com');",
        "جلب بيانات من API"),
    LibraryItem("موجه ترجمة", "ai", "text",
        "ترجم النص التالي إلى الإنجليزية بدقة:\n{{input}}",
        "قالب لترجمة النصوص"),
    LibraryItem("تنسيق تاريخ", "script", "javascript",
        "// تنسيق التاريخ\nconst d = new Date($input?.ts || Date.now());\nreturn { formatted: d.toLocaleString('ar') };",
        "تنسيق طابع زمني"),
    LibraryItem("استخراج روابط", "script", "javascript",
        "// استخراج الروابط من HTML\nconst regex = /href=\"([^\"]+)\"/g;\nconst out = [];\nlet m;\nwhile ((m = regex.exec($input.html)) !== null) out.push(m[1]);\nreturn out;",
        "استخراج الروابط التشعبية"),
    LibraryItem("Send Telegram", "action", "http",
        "POST https://api.telegram.org/bot<token>/sendMessage\n{\n  \"chat_id\": \"<id>\",\n  \"text\": \"{{input}}\"\n}",
        "إرسال رسالة تلغرام")
)
