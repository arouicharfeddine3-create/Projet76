package com.automation.workflow.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.automation.workflow.ui.viewmodel.RunnerViewModel
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RunnerScreen(vm: RunnerViewModel = koinViewModel()) {
    val workflows by vm.workflows.collectAsState()
    val selectedId by vm.selectedId.collectAsState()
    val logs by vm.logs.collectAsState()
    val status by vm.status.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2E7D32), Color(0xFF1B5E20))))
                .padding(20.dp)
        ) {
            Column {
                Text("▶️ شاشة التشغيل", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("شغّل سير العمل الخاص بك وراقب التنفيذ لحظياً", color = Color.White.copy(0.85f), fontSize = 13.sp)
            }
        }

        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            var expanded by remember { mutableStateOf(false) }
            val selected = workflows.firstOrNull { it.id == selectedId }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = selected?.name ?: "اختر سير عمل",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("سير العمل") },
                    leadingIcon = { Icon(Icons.Default.AccountTree, null) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().weight(1f)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    workflows.forEach { wf ->
                        DropdownMenuItem(text = { Text(wf.name) }, onClick = { vm.select(wf.id); expanded = false }, leadingIcon = { Text("📦") })
                    }
                }
            }
        }

        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.run() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047)),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("تشغيل")
            }
            OutlinedButton(onClick = { vm.stop() }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Stop, null, tint = Color(0xFFEF5350))
                Spacer(Modifier.width(6.dp))
                Text("إيقاف")
            }
            TextButton(onClick = { vm.clear() }) { Text("مسح السجل") }
        }

        Spacer(Modifier.height(10.dp))

        // Status card
        val stColor = when (status.name) {
            "RUNNING" -> Color(0xFFFFCA28)
            "SUCCESS" -> Color(0xFF66BB6A)
            "FAILED" -> Color(0xFFEF5350)
            "CANCELLED" -> Color(0xFF90A4AE)
            else -> Color.Gray
        }
        Card(
            modifier = Modifier.padding(horizontal = 12.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Memory, null, tint = stColor, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("الحالة", color = Color.White.copy(0.7f), fontSize = 12.sp)
                    Text(status.name, color = stColor, fontWeight = FontWeight.Bold)
                }
                Text("${logs.size} سجل", color = Color.White.copy(0.6f), fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("📋 سجل التنفيذ", Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.SemiBold)

        Surface(
            modifier = Modifier.padding(12.dp).fillMaxWidth().weight(1f),
            color = Color(0xFF0F172A), shape = RoundedCornerShape(12.dp)
        ) {
            if (logs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Terminal, null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("لا توجد سجلات بعد. اضغط تشغيل لتبدأ.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            } else {
                LazyColumn(Modifier.padding(10.dp)) {
                    items(logs) { line ->
                        val color = when {
                            line.level == "ERROR" || line.message.contains("❌") -> Color(0xFFEF5350)
                            line.level == "SUCCESS" || line.message.contains("✅") -> Color(0xFF66BB6A)
                            line.message.contains("⏸") -> Color(0xFFFFCA28)
                            else -> Color(0xFFBBDEFB)
                        }
                        Text("${line.time}  ${line.message}", color = color, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(2.dp))
                    }
                }
            }
        }
    }
}
