package com.automation.workflow.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import com.automation.workflow.domain.models.EditorNode
import com.automation.workflow.domain.models.NodeCategory
import com.automation.workflow.domain.models.NodeType
import com.automation.workflow.ui.editor.CodeEditorDialog
import com.automation.workflow.ui.editor.ExecutionLogPanel
import com.automation.workflow.ui.editor.NodeCard
import com.automation.workflow.ui.editor.NodePropertyPanel
import com.automation.workflow.ui.theme.GridColor
import com.automation.workflow.ui.viewmodel.EditorViewModel
import kotlinx.coroutines.delay
import org.koin.androidx.compose.koinViewModel
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.WrapContentHeight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items

private data class NodeLayout(
    val inputPorts: Map<String, Offset>,
    val outputPorts: Map<String, Offset>
)

@OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(workflowId: String, onBack: () -> Unit, vm: EditorViewModel = koinViewModel()) {
    LaunchedEffect(workflowId) { vm.load(workflowId) }

    val workflow by vm.workflow.collectAsState()
    val selectedId by vm.selectedNodeId.collectAsState()
    val editingId by vm.editingNodeId.collectAsState()
    val scale by vm.scale.collectAsState()
    val offX by vm.offsetX.collectAsState()
    val offY by vm.offsetY.collectAsState()
    val pending by vm.pending.collectAsState()
    val showAdd by vm.showAddMenu.collectAsState()
    val nodeSearch by vm.nodeSearch.collectAsState()
    val toast by vm.toast.collectAsState()
    val logs by vm.executionLog.collectAsState()
    val running by vm.isRunning.collectAsState()

    val nodeLayouts = remember { mutableStateMapOf<String, NodeLayout>() }
    val containerSize = remember { mutableStateOf(Offset.Zero) }
    val pointerPos = remember { mutableStateOf(Offset.Zero) }
    val showProps = remember { mutableStateOf(true) }
    val showLogs = remember { mutableStateOf(false) }

    LaunchedEffect(toast) {
        if (toast != null) { delay(2000); vm.clearToast() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(workflow?.name ?: "المحرر", fontWeight = FontWeight.Bold)
                        Text("${workflow?.nodes?.size ?: 0} عقدة · ${workflow?.connections?.size ?: 0} ربط · ${(scale*100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
                    }
                },
                navigationIcon = { IconButton(onClick = { vm.save(); onBack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { vm.showAddMenu(true) }) { Icon(Icons.Default.Add, null) }
                    IconButton(onClick = { vm.resetView() }) { Icon(Icons.Default.CenterFocusStrong, null) }
                    IconButton(onClick = { showLogs.value = !showLogs.value }) { Icon(Icons.Default.Terminal, null) }
                    IconButton(onClick = { showProps.value = !showProps.value }) { Icon(Icons.Default.Tune, null) }
                    IconButton(onClick = { vm.save() }) { Icon(Icons.Default.Save, null) }
                    IconButton(onClick = { if (!running) vm.runWorkflow() }, enabled = !running) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color(0xFF66BB6A))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End) {
                SmallFloatingActionButton(onClick = { vm.zoomAt(containerSize.value.x/2, containerSize.value.y/2, scale * 1.2f) },
                    containerColor = MaterialTheme.colorScheme.surface) { Icon(Icons.Default.ZoomIn, null) }
                Spacer(Modifier.height(8.dp))
                SmallFloatingActionButton(onClick = { vm.zoomAt(containerSize.value.x/2, containerSize.value.y/2, scale * 0.83f) },
                    containerColor = MaterialTheme.colorScheme.surface) { Icon(Icons.Default.ZoomOut, null) }
                Spacer(Modifier.height(8.dp))
                SmallFloatingActionButton(onClick = { vm.showAddMenu(true) }, containerColor = MaterialTheme.colorScheme.primary) {
                    Icon(Icons.Default.Add, null, tint = Color.White)
                }
            }
        }
    ) { pad ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .background(Color(0xFF0A0F1C))
                .onGloballyPositioned {
                    containerSize.value = Offset(it.size.width.toFloat(), it.size.height.toFloat())
                }
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: continue
                            pointerPos.value = change.position
                            val p = pending
                            if (p != null && change.pressed) {
                                vm.updatePending(change.position.x, change.position.y)
                            }
                            if (!change.pressed && p != null) {
                                // Find target port at pointer position
                                val hit = hitTestPort(nodeLayouts, change.position, exceptNodeId = p.fromNodeId)
                                if (hit != null) {
                                    vm.completeConnection(hit.first, hit.second, hit.third)
                                } else {
                                    vm.cancelConnection()
                                }
                            }
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        vm.zoomAt(centroid.x, centroid.y, scale * zoom)
                        vm.panBy(pan.x, pan.y)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onTap = {
                        vm.selectNode(null)
                        vm.cancelConnection()
                    })
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val grid = 24f * scale
                val startX = offX % grid
                val startY = offY % grid
                var x = startX
                while (x < size.width) {
                    drawLine(GridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    x += grid
                }
                var y = startY
                while (y < size.height) {
                    drawLine(GridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += grid
                }

                val wf = workflow ?: return@Canvas
                for (conn in wf.connections) {
                    val from = nodeLayouts[conn.fromNodeId]?.outputPorts?.get(conn.fromPortId)
                    val to = nodeLayouts[conn.toNodeId]?.inputPorts?.get(conn.toPortId)
                    if (from != null && to != null) {
                        drawCurve(from, to, Color(conn.color), 3f * scale, dashed = false)
                    }
                }
                val p = pending
                if (p != null) {
                    val src = if (p.isFromOutput) nodeLayouts[p.fromNodeId]?.outputPorts?.get(p.fromPortId)
                              else nodeLayouts[p.fromNodeId]?.inputPorts?.get(p.fromPortId)
                    val end = Offset(p.currentX, p.currentY)
                    if (src != null) drawCurve(src, end, Color(0xFFFFCA28), 3f * scale, dashed = true)
                }
            }

            val wf = workflow
            if (wf != null) {
                for (node in wf.nodes) {
                    key(node.id) {
                        val isSel = node.id == selectedId
                        NodeCard(
                            node = node,
                            isSelected = isSel,
                            scale = scale,
                            offsetX = offX,
                            offsetY = offY,
                            onSelect = { vm.selectNode(node.id) },
                            onOpenScript = { vm.openScriptEditor(node.id) },
                            onDragStart = { px, py -> },
                            onDrag = { px, py ->
                                val nx = (px - offX) / scale
                                val ny = (py - offY) / scale
                                vm.updateNodePosition(node.id, nx - node.width/2, ny - 30f)
                            },
                            onDragEnd = { },
                            onDelete = { vm.deleteNode(node.id) },
                            onDuplicate = { vm.duplicateNode(node.id) },
                            onToggleBreakpoint = { vm.toggleBreakpoint(node.id) },
                            onToggleDisable = { vm.toggleDisabled(node.id) },
                            onPortPressed = { portId, isOut, rootPos ->
                                vm.startConnection(node.id, portId, isOut, rootPos.x, rootPos.y)
                            },
                            onRegisterLayout = { _, _, _, _, ins, outs ->
                                nodeLayouts[node.id] = NodeLayout(ins, outs)
                            }
                        )
                    }
                }
            }

            if (toast != null) {
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).padding(16.dp),
                    color = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(12.dp),
                    tonalElevation = 8.dp
                ) {
                    Text(toast!!, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = Color.White)
                }
            }
        }

        if (showProps.value) {
            val sel = workflow?.nodes?.firstOrNull { it.id == selectedId }
            if (sel != null) {
                NodePropertyPanel(
                    node = sel,
                    onClose = { showProps.value = false },
                    onOpenScript = { vm.openScriptEditor(sel.id) },
                    onTitleChange = { vm.updateNodeTitle(sel.id, it) },
                    onConfigChange = { k, v -> vm.updateNodeConfig(sel.id, k, v) },
                    onDelete = { vm.deleteNode(sel.id) },
                    onDuplicate = { vm.duplicateNode(sel.id) },
                    onBreakpoint = { vm.toggleBreakpoint(sel.id) },
                    onDisable = { vm.toggleDisabled(sel.id) },
                    onDeleteConnection = { cid -> vm.deleteConnection(cid) },
                    modifier = Modifier.padding(pad)
                )
            }
        }

        if (showLogs.value) {
            ExecutionLogPanel(logs = logs, running = running, onClose = { showLogs.value = false })
        }
    }

    if (showAdd) {
        AddNodeDialog(
            search = nodeSearch,
            onSearch = { vm.setSearch(it) },
            onDismiss = { vm.showAddMenu(false) },
            onPick = { tmpl ->
                val sz = containerSize.value
                val cx = (sz.x/2 - offX)/scale - 110f
                val cy = (sz.y/2 - offY)/scale - 60f
                vm.addNode(tmpl, cx, cy)
            }
        )
    }

    val editingNode = workflow?.nodes?.firstOrNull { it.id == editingId }
    if (editingNode != null) {
        CodeEditorDialog(
            node = editingNode,
            onClose = { vm.closeScriptEditor() },
            onSave = { code ->
                vm.updateNodeScript(editingNode.id, code)
                vm.closeScriptEditor()
            }
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCurve(
    from: Offset, to: Offset, color: Color, width: Float, dashed: Boolean
) {
    val dx = (to.x - from.x).coerceAtLeast(40f)
    val cp1 = Offset(from.x + dx * 0.5f, from.y)
    val cp2 = Offset(to.x - dx * 0.5f, to.y)
    val path = Path().apply {
        moveTo(from.x, from.y)
        cubicTo(cp1.x, cp1.y, cp2.x, cp2.y, to.x, to.y)
    }
    drawPath(path, color = color, style = Stroke(width = width,
        pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(16f,8f), 0f) else null))
    drawCircle(color, radius = width + 2f, center = to)
}

private fun hitTestPort(layouts: Map<String, NodeLayout>, pos: Offset, exceptNodeId: String): Triple<String, String, Boolean>? {
    val radius = 22f
    for ((nid, lay) in layouts) {
        if (nid == exceptNodeId) continue
        for ((pid, p) in lay.inputPorts) {
            if ((p - pos).getDistance() < radius) return Triple(nid, pid, false)
        }
        for ((pid, p) in lay.outputPorts) {
            if ((p - pos).getDistance() < radius) return Triple(nid, pid, true)
        }
    }
    return null
}

@Composable
fun AddNodeDialog(search: String, onSearch: (String) -> Unit, onDismiss: () -> Unit, onPick: (com.automation.workflow.domain.models.NodeTemplate) -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 12.dp,
            modifier = Modifier.fillMaxHeight(0.85f).fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("➕ إضافة عقدة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = onSearch,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    placeholder = { Text("ابحث عن نوع عقدة...") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                val grouped = NodeType.templates()
                    .filter { it.title.contains(search, true) || it.category.displayNameAr.contains(search, true) }
                    .groupBy { it.category }
                LazyColumn {
                    grouped.forEach { (cat, items) ->
                        stickyHeader {
                            Surface(color = cat.color.copy(0.15f), modifier = Modifier.fillMaxWidth()) {
                                Text("  ${cat.displayNameAr}", color = cat.color, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 6.dp))
                            }
                        }
                        item {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items.chunked(2).forEach { row ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        row.forEach { tmpl ->
                                            ElevatedAssistChip(
                                                onClick = { onPick(tmpl) },
                                                label = { Text(tmpl.title, fontSize = 11.sp) },
                                                leadingIcon = { Text(tmpl.icon) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        if (row.size == 1) Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
