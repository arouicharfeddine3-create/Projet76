package com.automation.workflow.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.automation.workflow.domain.models.EditorNode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeEditorDialog(
    node: EditorNode,
    onClose: () -> Unit,
    onSave: (String) -> Unit
) {
    var code by remember(node.id) { mutableStateOf(node.script) }
    var showSnippets by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(0.dp),
            color = Color(0xFF0F172A),
            contentColor = Color(0xFFE2E8F0)
        ) {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text("✏️ محرر السكريبت", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Text(node.title, fontSize = 11.sp, color = Color.White.copy(0.7f))
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                    },
                    actions = {
                        IconButton(onClick = { showSnippets = !showSnippets }) {
                            Icon(Icons.Default.Lightbulb, null, tint = Color(0xFFFFCA28))
                        }
                        IconButton(onClick = { code = node.script }) {
                            Icon(Icons.Default.Undo, null, tint = Color.White)
                        }
                        Button(
                            onClick = { onSave(code) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF66BB6A))
                        ) {
                            Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("حفظ", color = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E293B))
                )

                if (showSnippets) {
                    SnippetsBar(onInsert = { snippet ->
                        code = code + "\n" + snippet
                        showSnippets = false
                    })
                }

                Row(modifier = Modifier.weight(1f)) {
                    // Line numbers
                    val lines = code.lines()
                    Box(
                        Modifier
                            .width(48.dp)
                            .fillMaxHeight()
                            .background(Color(0xFF1E293B))
                            .padding(top = 8.dp, end = 6.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.verticalScroll(rememberScrollState())) {
                            lines.indices.forEach { idx ->
                                Text(
                                    "${idx+1}",
                                    color = Color(0xFF64748B),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }

                    BasicTextField(
                        value = code,
                        onValueChange = { code = it },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(Color(0xFF0F172A))
                            .padding(8.dp),
                        textStyle = TextStyle(
                            color = Color(0xFFE2E8F0),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        ),
                        cursorBrush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFFFFCA28), Color(0xFFFFCA28))),
                        decorationBox = { inner ->
                            Box { inner() }
                        }
                    )
                }

                // Bottom bar
                Surface(color = Color(0xFF1E293B), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SuggestionPill(n = node) { snippet -> code = code + snippet }
                        Spacer(Modifier.weight(1f))
                        Text(
                            "${code.length} حرف · ${code.lines().size} سطر",
                            color = Color.White.copy(0.6f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SnippetsBar(onInsert: (String) -> Unit) {
    val snippets = listOf(
        "📡 HTTP" to "// جلب بيانات\nfetch('https://api.example.com/data')\n  .then(r => r.json())\n  .then(d => ({ result: d }));",
        "🔁 Loop" to "// حلقة\nconst arr = input?.items || [];\nconst results = [];\nfor (const item of arr) {\n  results.push(item);\n}\nreturn results;",
        "❓ If" to "// شرط\nif (input && input.value > 0) {\n  return { ok: true, value: input.value };\n} else {\n  return { ok: false };",
        "📝 Log" to "console.log('تشغيل العقدة', input);\nreturn input;",
        "⏳ Delay" to "await new Promise(r => setTimeout(r, 1000));\nreturn input;",
        "🤖 AI" to "// طلب ذكاء اصطناعي\nreturn await ai.complete(\"لخّص: \" + JSON.stringify(input));"
    )
    Surface(color = Color(0xFF1E293B), modifier = Modifier.fillMaxWidth().height(60.dp)) {
        Row(
            modifier = Modifier.padding(6.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            snippets.forEach { (name, code) ->
                ElevatedAssistChip(onClick = { onInsert(code) }, label = { Text(name, fontSize = 11.sp) })
            }
        }
    }
}

@Composable
private fun SuggestionPill(n: EditorNode, onInsert: (String) -> Unit) {
    val suggestions = remember(n.type) {
        listOf(
            "\$input" to "الإدخال",
            "\$nodes" to "العقد",
            "\$env" to "البيئة",
            "console.log()" to "سجل"
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        suggestions.forEach { (s, l) ->
            SuggestionChip(
                onClick = { onInsert(s) },
                label = { Text(l, fontSize = 10.sp) }
            )
        }
    }
}
