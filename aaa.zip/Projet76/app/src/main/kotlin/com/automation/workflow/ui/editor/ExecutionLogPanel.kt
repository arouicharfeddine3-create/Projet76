package com.automation.workflow.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ExecutionLogPanel(logs: List<String>, running: Boolean, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        Surface(
            modifier = Modifier.fillMaxWidth().height(280.dp),
            color = Color(0xFF0F172A),
            tonalElevation = 10.dp,
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                        .background(Color(0xFF1E293B), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Terminal, null, tint = Color(0xFF66BB6A))
                    Spacer(Modifier.width(8.dp))
                    Text(if (running) "🟢 جاري التشغيل..." else "سجل التنفيذ",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.weight(1f))
                    if (running) CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color(0xFF66BB6A),
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = Color.White) }
                }
                LazyColumn(modifier = Modifier.padding(horizontal = 12.dp)) {
                    itemsIndexed(logs) { i, line ->
                        val color = when {
                            line.contains("✅") -> Color(0xFF66BB6A)
                            line.contains("❌") || line.contains("خطأ") -> Color(0xFFEF5350)
                            line.contains("⏸️") -> Color(0xFFFFCA28)
                            line.contains("⚙️") -> Color(0xFF64B5F6)
                            line.contains("▶️") -> Color(0xFF42A5F5)
                            line.contains("🏁") -> Color(0xFFAB47BC)
                            else -> Color(0xFFE0E0E0)
                        }
                        Text(line,
                            color = color,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
