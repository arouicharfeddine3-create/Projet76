package com.automation.workflow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.automation.workflow.domain.models.NodeCategory
import com.automation.workflow.domain.models.NodeType
import com.automation.workflow.ui.viewmodel.LibraryViewModel
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(vm: LibraryViewModel = koinViewModel()) {
    val scripts by vm.scripts.collectAsState()
    val selected by vm.selected.collectAsState()
    val query by vm.query.collectAsState()
    val templates = vm.templates()
    var tab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF6A1B9A), Color(0xFF4A148C))))
                .padding(20.dp)
        ) {
            Column {
                Text("📚 المكتبة", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("مكتبة السكريبتات والعقد الجاهزة", color = Color.White.copy(0.85f), fontSize = 13.sp)
            }
        }

        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.surface) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("السكريبتات") }, icon = { Icon(Icons.Default.Code, null, modifier = Modifier.size(16.dp)) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("العقد") }, icon = { Icon(Icons.Default.AccountTree, null, modifier = Modifier.size(16.dp)) })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("المجتمع") }, icon = { Icon(Icons.Default.People, null, modifier = Modifier.size(16.dp)) })
        }

        OutlinedTextField(
            value = query,
            onValueChange = { vm.filter(it) },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("🔍 ابحث...") },
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )

        when (tab) {
            0 -> ScriptsTab(scripts, selected, onSelect = { vm.select(it) }, onAdd = { vm.addNew() }, onCodeChange = { vm.updateCode(it) })
            1 -> NodesTab(templates)
            2 -> CommunityTab()
        }
    }
}

@Composable
fun ScriptsTab(items: List<com.automation.workflow.ui.viewmodel.LibraryItem>, selected: com.automation.workflow.ui.viewmodel.LibraryItem?,
               onSelect: (com.automation.workflow.ui.viewmodel.LibraryItem) -> Unit, onAdd: () -> Unit, onCodeChange: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxSize()) {
        LazyColumn(Modifier.width(220.dp).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("جديد")
                }
            }
            items(items) { it ->
                ElevatedCard(
                    onClick = { onSelect(it) },
                    colors = CardDefaults.cardColors(containerColor = if (selected?.name == it.name) Color(0xFF1E88E5).copy(0.2f) else MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                when (it.language) {
                                    "javascript" -> "🟨"
                                    "python" -> "🐍"
                                    "ai" -> "🤖"
                                    "http" -> "🌐"
                                    else -> "📜"
                                }
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(it.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        }
                        Text(it.description, color = Color.Gray, fontSize = 11.sp, maxLines = 2)
                    }
                }
            }
        }
        Divider(Modifier.fillMaxHeight().width(1.dp))
        Box(Modifier.weight(1f).padding(10.dp)) {
            if (selected == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("اختر سكريبتاً لعرضه", color = Color.Gray)
                }
            } else {
                Column {
                    Text(selected.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(selected.description, color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Surface(modifier = Modifier.fillMaxSize().weight(1f), color = Color(0xFF0F172A), shape = RoundedCornerShape(10.dp)) {
                        var code by remember(selected.name) { mutableStateOf(selected.code) }
                        BasicTextField(
                            value = code,
                            onValueChange = { code = it; onCodeChange(it) },
                            modifier = Modifier.fillMaxSize().padding(10.dp),
                            textStyle = LocalTextStyle.current.copy(color = Color(0xFFE2E8F0), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NodesTab(templates: List<com.automation.workflow.domain.models.NodeTemplate>) {
    val grouped = templates.groupBy { it.category }
    LazyColumn(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        grouped.forEach { (cat, items) ->
            item {
                Text(cat.displayNameAr, color = cat.color, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { t ->
                                ElevatedAssistChip(onClick = { },
                                    label = { Text(t.title, fontSize = 11.sp) },
                                    leadingIcon = { Text(t.icon) },
                                    modifier = Modifier.weight(1f))
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun CommunityTab() {
    val samples = listOf(
        "🤖 تلخيص مقالات من الويب تلقائياً" to "يقرأ روابط RSS ويلخّص كل مقال عبر GPT ويرسله لتلغرام",
        "📊 تحويل HTML إلى CSV" to "يستخرج الجداول من أي صفحة ويب ويحولها لملف CSV",
        "🔔 تنبيه الأسعار" to "يراقب سعر منتج في متجر ويرسل إشعاراً عند انخفاضه",
        "📅 جدولة يومية" to "يرسل تقريراً يومياً بالطقس والمهام والبريد",
        "📸 أرشيف الصور" to "ينسخ الصور من واتساب ويحفظها في مجلد منظم",
        "🌍 ترجمة فورية" to "يستمع لإشعارات التطبيقات ويترجمها فوراً"
    )
    LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(samples) { (t, d) ->
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Text(t, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(d, color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Row {
                        AssistChip(onClick = { }, label = { Text("استيراد", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.Download, null, modifier = Modifier.size(14.dp)) })
                        Spacer(Modifier.width(6.dp))
                        AssistChip(onClick = { }, label = { Text("⭐ التقييم", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.Star, null, modifier = Modifier.size(14.dp)) })
                    }
                }
            }
        }
    }
}
