package com.automation.workflow.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.automation.workflow.domain.models.Workflow
import com.automation.workflow.ui.viewmodel.HomeViewModel
import org.koin.androidx.compose.koinViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (String) -> Unit, vm: HomeViewModel = koinViewModel()) {
    val workflows by vm.workflows.collectAsState()
    val search by vm.searchQuery.collectAsState()
    var showNewDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFF1565C0), Color(0xFF0D47A1))))
                .padding(20.dp)
        ) {
            Column {
                Text("🚀 مهام سير العمل الآلية", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("أنشئ، حرّر، وشغّل مهامك بسهولة عبر نظام العقد", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.9f))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { vm.search(it) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.White) },
                    placeholder = { Text("🔍 ابحث عن سير عمل...", color = Color.White.copy(0.7f)) },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.White,
                        unfocusedBorderColor = Color.White.copy(0.5f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White
                    )
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("📋 المشاريع (${workflows.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Button(onClick = { showNewDialog = true; newName = "سير عمل جديد" }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("جديد")
            }
        }

        if (workflows.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.HourglassEmpty, null, modifier = Modifier.size(64.dp), tint = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    Text("لا توجد مشاريع بعد", color = Color.Gray)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(170.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(workflows) { wf ->
                    WorkflowCard(wf, onClick = { onOpen(wf.id) }, onDelete = { vm.delete(wf.id) })
                }
            }
        }
    }

    if (showNewDialog) {
        AlertDialog(
            onDismissRequest = { showNewDialog = false },
            title = { Text("سير عمل جديد") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("الاسم") })
            },
            confirmButton = {
                Button(onClick = {
                    val wf = vm.createNew(newName.ifBlank { "سير عمل جديد" })
                    showNewDialog = false
                    onOpen(wf.id)
                }) { Text("إنشاء") }
            },
            dismissButton = { TextButton(onClick = { showNewDialog = false }) { Text("إلغاء") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkflowCard(wf: Workflow, onClick: () -> Unit, onDelete: () -> Unit) {
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US) }
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF1E88E5).copy(0.9f), Color(0xFF8E24AA).copy(0.7f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AccountTree, null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(wf.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text("${wf.nodes.size} عقدة · ${wf.connections.size} ربط", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Text(fmt.format(Date(wf.updatedAt)), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                AssistChip(onClick = onClick, label = { Text("فتح") }, leadingIcon = { Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(14.dp)) })
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
