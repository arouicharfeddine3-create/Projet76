package com.automation.workflow.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.automation.workflow.domain.models.EditorNode
import com.automation.workflow.domain.models.NodeTemplate
import com.automation.workflow.domain.models.PortFlowType
import kotlin.math.roundToInt

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun NodeCard(
    node: EditorNode,
    isSelected: Boolean,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    onSelect: () -> Unit,
    onOpenScript: () -> Unit,
    onDragStart: (Float, Float) -> Unit,
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit,
    onToggleBreakpoint: () -> Unit,
    onToggleDisable: () -> Unit,
    onPortPressed: (portId: String, isOutput: Boolean, rootPos: Offset) -> Unit,
    onRegisterLayout: (nodeX: Float, nodeY: Float, w: Float, h: Float,
                        inputs: Map<String, Offset>, outputs: Map<String, Offset>) -> Unit
) {
    val tmpl = remember(node.type) { NodeTemplateLookup[node.type] }
    val inputs = tmpl?.inputs?.filter { it.flow == PortFlowType.TRIGGER } ?: emptyList()
    val outputs = tmpl?.outputs?.filter { it.flow == PortFlowType.TRIGGER } ?: emptyList()

    val color = Color(node.color)
    val bgColor = if (node.isDisabled) Color(0xFF455A64) else color

    val nodeRootPos = remember { mutableStateOf(Offset.Zero) }
    val portCenters = remember { mutableStateMapOf<String, Offset>() }

    Box(
        Modifier
            .offset { IntOffset(((node.x * scale + offsetX)).roundToInt(), ((node.y * scale + offsetY)).roundToInt()) }
            .zIndex(if (isSelected) 10f else 1f)
            .shadow(if (isSelected) 12.dp else 4.dp, RoundedCornerShape(12.dp))
            .width((node.width * scale).dp)
            .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
            .onGloballyPositioned { c ->
                val b = c.boundsInRoot()
                nodeRootPos.value = Offset(b.left, b.top)
                val inP = mutableMapOf<String, Offset>()
                val outP = mutableMapOf<String, Offset>()
                inputs.forEach { p -> portCenters["in_${p.id}"]?.let { inP[p.id] = it } }
                outputs.forEach { p -> portCenters["out_${p.id}"]?.let { outP[p.id] = it } }
                onRegisterLayout(b.left, b.top, b.width, b.height, inP, outP)
            }
            .pointerInput(node.id) {
                detectDragGestures(
                    onDragStart = { onSelect(); onDragStart(it.x, it.y) },
                    onDrag = { change, _ ->
                        change.consume()
                        onDrag(nodeRootPos.value.x + change.position.x, nodeRootPos.value.y + change.position.y)
                    },
                    onDragEnd = onDragEnd
                )
            }
            .pointerInput(node.id) {
                detectTapGestures(onTap = { onSelect() }, onDoubleTap = { onOpenScript() })
            }
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(bgColor, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tmpl?.icon ?: "⚡", fontSize = (14 * scale).sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    node.title,
                    color = Color.White,
                    fontSize = (12 * scale).sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                if (node.isBreakpoint) Icon(Icons.Default.Adjust, null, tint = Color(0xFFFF5252), modifier = Modifier.size((14*scale).dp))
                if (node.isDisabled) Icon(Icons.Default.Block, null, tint = Color.White.copy(0.7f), modifier = Modifier.size((14*scale).dp))
                Icon(Icons.Default.Code, null, tint = Color.White.copy(0.85f),
                    modifier = Modifier.size((14*scale).dp).clickable { onOpenScript() })
            }

            Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                if (node.config.isNotEmpty()) {
                    node.config.entries.take(3).forEach { (k, v) ->
                        Text("• $k: ${v.ifBlank { "—" }}", color = Color.White.copy(0.8f),
                            fontSize = (10 * scale.coerceAtLeast(0.7f)).sp, maxLines = 1)
                    }
                    if (node.config.size > 3) Text("…", color = Color.White.copy(0.5f), fontSize = (10 * scale).sp)
                } else {
                    Text(
                        node.script.lineSequence().firstOrNull()?.take(30) ?: "—",
                        color = Color.White.copy(0.6f), fontSize = (10*scale).sp, maxLines = 2
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    AssistChip(
                        onClick = onOpenScript,
                        label = { Text("السكريبت", fontSize = 10.sp) },
                        leadingIcon = { Icon(Icons.Default.Edit, null, modifier = Modifier.size(12.dp)) },
                        modifier = Modifier.height(24.dp)
                    )
                    AssistChip(
                        onClick = onToggleDisable,
                        label = { Text(if (node.isDisabled) "مفعّل" else "تعطيل", fontSize = 10.sp) },
                        leadingIcon = { Icon(if (node.isDisabled) Icons.Default.PlayArrow else Icons.Default.Pause, null, modifier = Modifier.size(12.dp)) },
                        modifier = Modifier.height(24.dp)
                    )
                }
            }
        }

        Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().padding(start = (-7).dp), contentAlignment = Alignment.Center) {
            Column(verticalArrangement = Arrangement.spacedBy((10*scale).dp)) {
                inputs.forEach { p ->
                    PortDot(color = Color(0xFF64B5F6),
                        onPosition = { portCenters["in_${p.id}"] = it },
                        onPressed = { pos -> onPortPressed(p.id, false, pos) })
                }
            }
        }

        Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(end = (-7).dp), contentAlignment = Alignment.Center) {
            Column(verticalArrangement = Arrangement.spacedBy((10*scale).dp)) {
                outputs.forEach { p ->
                    PortDot(color = Color(0xFFFFCA28),
                        onPosition = { portCenters["out_${p.id}"] = it },
                        onPressed = { pos -> onPortPressed(p.id, true, pos) })
                }
            }
        }

        if (isSelected) {
            Canvas(Modifier.matchParentSize()) {
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset.Zero, size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()),
                    style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f,6f)))
                )
            }
            Row(Modifier.align(Alignment.TopEnd).offset(6.dp, (-14).dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(onClick = onToggleBreakpoint, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Adjust, null, tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDuplicate, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.ContentCopy, null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, null, tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

private val NodeTemplateLookup by lazy {
    com.automation.workflow.domain.models.NodeType.templates().associateBy { it.type }
}

@Composable
private fun PortDot(
    color: Color,
    onPosition: (Offset) -> Unit,
    onPressed: (Offset) -> Unit
) {
    var center by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier
            .size(14.dp)
            .clip(CircleShape)
            .background(color)
            .onGloballyPositioned { c ->
                val b = c.boundsInRoot()
                center = Offset(b.left + b.width/2, b.top + b.height/2)
                onPosition(center)
            }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val down = awaitPointerEvent().changes.firstOrNull { it.changedToDown() } ?: continue
                        down.consume()
                        onPressed(center)
                    }
                }
            }
    )
}
