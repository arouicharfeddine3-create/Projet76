package com.automation.workflow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.automation.workflow.ui.viewmodel.SettingsViewModel
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: SettingsViewModel = koinViewModel()) {
    val s by vm.state.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF37474F), Color(0xFF263238))))
                .padding(20.dp)
        ) {
            Column {
                Text("⚙️ الإعدادات", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("خصّص التطبيق حسب احتياجاتك", color = Color.White.copy(0.85f), fontSize = 13.sp)
            }
        }

        LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Section("🎨 المظهر") }
            item {
                SettingSwitch("الوضع الداكن", s.darkMode, Icons.Default.DarkMode) { vm.update { it.copy(darkMode = !s.darkMode) } }
            }
            item {
                SettingSwitch("العربية (RTL)", s.arabic, Icons.Default.Language) { vm.update { it.copy(arabic = !s.arabic) } }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    Text("حجم الخط", modifier = Modifier.weight(1f))
                    Slider(value = s.fontSize.toFloat(), onValueChange = { vm.update { st -> st.copy(fontSize = it.toInt()) } },
                        valueRange = 10f..20f, steps = 9, modifier = Modifier.width(160.dp))
                    Text("${s.fontSize}sp")
                }
            }

            item { Section("🚀 الأداء") }
            item { SettingSwitch("حفظ تلقائي", s.autoSave, Icons.Default.Save) { vm.update { it.copy(autoSave = !s.autoSave) } } }
            item { SettingSwitch("توفير البطارية", s.batterySaver, Icons.Default.BatterySaver) { vm.update { it.copy(batterySaver = !s.batterySaver) } } }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    Text("مهلة العقدة (ثانية)", modifier = Modifier.weight(1f))
                    Slider(value = s.nodeTimeout / 1000f, onValueChange = { vm.update { st -> st.copy(nodeTimeout = (it*1000).toLong()) } },
                        valueRange = 5f..120f, modifier = Modifier.width(160.dp))
                    Text("${s.nodeTimeout/1000}s")
                }
            }

            item { Section("🎛️ المحرر") }
            item { SettingSwitch("عرض الشبكة", s.gridEnabled, Icons.Default.GridOn) { vm.update { it.copy(gridEnabled = !s.gridEnabled) } } }
            item { SettingSwitch("الالتصاق بالشبكة", s.snapToGrid, Icons.Default.SpaceDashboard) { vm.update { it.copy(snapToGrid = !s.snapToGrid) } } }
            item { SettingSwitch("حركة الوصلات", s.animateConnections, Icons.Default.Animation) { vm.update { it.copy(animateConnections = !s.animateConnections) } } }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    Text("سرعة الحركة", modifier = Modifier.weight(1f))
                    Slider(value = s.animationSpeed, onValueChange = { vm.update { st -> st.copy(animationSpeed = it) } },
                        valueRange = 0.3f..2f, modifier = Modifier.width(160.dp))
                    Text("${(s.animationSpeed*100).toInt()}%")
                }
            }

            item { Section("🔔 الإشعارات والأمان") }
            item { SettingSwitch("إشعارات", s.notifications, Icons.Default.Notifications) { vm.update { it.copy(notifications = !s.notifications) } } }
            item { SettingSwitch("الأصوات", s.sounds, Icons.Default.VolumeUp) { vm.update { it.copy(sounds = !s.sounds) } } }
            item { SettingSwitch("الاهتزاز", s.vibration, Icons.Default.Vibration) { vm.update { it.copy(vibration = !s.vibration) } } }
            item { SettingSwitch("القفل بالبصمة", s.biometric, Icons.Default.Fingerprint) { vm.update { it.copy(biometric = !s.biometric) } } }

            item { Section("ℹ️ حول") }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Projet76 · Workflow Automation", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("الإصدار 2.0.0 · مُحسَّن بواجهة جديدة", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("✨ عقد كثيرة · تحرير سكريبت مباشر · وصلات محسّنة", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {}) { Text("تصدير نسخة احتياطية") }
                            FilledTonalButton(onClick = {}) { Text("استيراد") }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
fun Section(title: String) {
    Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp))
}

@Composable
fun SettingSwitch(title: String, value: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, onToggle: () -> Unit) {
    ElevatedCard(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text(title, modifier = Modifier.weight(1f))
            Switch(checked = value, onCheckedChange = { onToggle() })
        }
    }
}
