package com.automation.workflow.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.automation.workflow.ui.screens.*
import com.automation.workflow.ui.theme.WorkflowTheme
import org.koin.androidx.viewmodel.ext.android.viewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "سير العمل", Icons.Default.Home)
    object Editor : Screen("editor/{id}", "المحرر", Icons.Default.AccountTree) {
        fun withId(id: String) = "editor/$id"
        const val ARG_ID = "id"
    }
    object Runner : Screen("runner", "التشغيل", Icons.Default.PlayArrow)
    object Library : Screen("library", "المكتبة", Icons.Default.MenuBook)
    object Browser : Screen("browser", "المتصفح", Icons.Default.Language)
    object Workspace : Screen("workspace", "مساحة العمل", Icons.Default.Folder)
    object Settings : Screen("settings", "الإعدادات", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WorkflowTheme(darkTheme = true) {
                AppRoot()
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val screens = listOf(Screen.Home, Screen.Runner, Screen.Library, Screen.Browser, Screen.Workspace, Screen.Settings)
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val isEditor = currentRoute?.startsWith("editor/") == true

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!isEditor) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp) {
                    screens.forEach { s ->
                        NavigationBarItem(
                            icon = { Icon(s.icon, contentDescription = s.title) },
                            label = { Text(s.title) },
                            selected = currentRoute == s.route,
                            onClick = {
                                if (currentRoute != s.route) {
                                    nav.navigate(s.route) {
                                        popUpTo(Screen.Home.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Home.route) { HomeScreen(onOpen = { id -> nav.navigate(Screen.Editor.withId(id)) }) }
            composable(
                Screen.Editor.route,
                arguments = listOf(navArgument(Screen.Editor.ARG_ID) { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString(Screen.Editor.ARG_ID) ?: return@composable
                EditorScreen(workflowId = id, onBack = { nav.popBackStack() })
            }
            composable(Screen.Runner.route) { RunnerScreen() }
            composable(Screen.Library.route) { LibraryScreen() }
            composable(Screen.Browser.route) { BrowserScreen() }
            composable(Screen.Workspace.route) { WorkspaceScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
