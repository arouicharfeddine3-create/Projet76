package com.automation.workflow.ui.screens

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen() {
    var url by remember { mutableStateOf("https://www.google.com") }
    var inputUrl by remember { mutableStateOf(url) }
    var isLoading by remember { mutableStateOf(false) }
    var captureMode by remember { mutableStateOf(false) }
    var recordMode by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF00695C), Color(0xFF004D40))))
                .padding(12.dp)
        ) {
            Column {
                Text("🌐 المتصفح المدمج", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("سجّل Raccord، التقط selectors، واستخرج البيانات", color = Color.White.copy(0.85f), fontSize = 13.sp)
            }
        }

        // URL bar
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = inputUrl,
                onValueChange = { inputUrl = it },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Link, null) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("https://...") }
            )
            Button(onClick = { url = if (!inputUrl.startsWith("http")) "https://$inputUrl" else inputUrl }) {
                Icon(Icons.Default.Navigation, null)
            }
        }

        // Tools
        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = captureMode, onClick = { captureMode = !captureMode },
                label = { Text("التقاط Selector", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.TouchApp, null, modifier = Modifier.size(14.dp)) })
            FilterChip(selected = recordMode, onClick = { recordMode = !recordMode },
                label = { Text("تسجيل Raccord", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.FiberManualRecord, null, modifier = Modifier.size(14.dp), tint = Color.Red) })
            AssistChip(onClick = { /* TODO: extract */ }, label = { Text("استخراج", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.Download, null, modifier = Modifier.size(14.dp)) })
            AssistChip(onClick = { }, label = { Text("Console", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.Terminal, null, modifier = Modifier.size(14.dp)) })
        }

        Spacer(Modifier.height(6.dp))

        Box(Modifier.weight(1f).padding(8.dp).background(Color.White, RoundedCornerShape(12.dp))) {
            AndroidView(factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isLoading = false
                        }
                    }
                    loadUrl(url)
                }
            }, update = { it.loadUrl(url) })
            if (isLoading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopStart))
        }

        BottomAppBar {
            IconButton(onClick = {}) { Icon(Icons.Default.ArrowBack, null) }
            IconButton(onClick = {}) { Icon(Icons.Default.ArrowForward, null) }
            IconButton(onClick = {}) { Icon(Icons.Default.Refresh, null) }
            IconButton(onClick = {}) { Icon(Icons.Default.Home, null) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = {}) { Icon(Icons.Default.Add, null) }
            IconButton(onClick = {}) { Icon(Icons.Default.Settings, null) }
        }
    }
}
